class Api::CategoriesController < ApplicationController
  
end
