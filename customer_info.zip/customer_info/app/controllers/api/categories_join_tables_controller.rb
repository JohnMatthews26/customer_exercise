class Api::CategoriesJoinTablesController < ApplicationController
end
