class Api::ProductsController < ApplicationController
end
