module Api::ProductHelper
end
