require 'test_helper'

class Api::CategoriesJoinTablesControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
